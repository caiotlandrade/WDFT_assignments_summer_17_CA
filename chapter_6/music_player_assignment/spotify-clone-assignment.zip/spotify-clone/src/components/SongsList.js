import React, {Component} from 'react';

class SongsList extends Component {
    render() {
        console.log(this.props)
        return (
            <div>
            </div>
        )
    }
}

export default SongsList;