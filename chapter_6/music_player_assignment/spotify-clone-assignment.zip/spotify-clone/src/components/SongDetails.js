import React, {Component} from 'react';

class SongDetails extends Component {
    render() {
        console.log(this.props)
        return (
            <div>
            </div>
        )
    }
}

export default SongDetails;